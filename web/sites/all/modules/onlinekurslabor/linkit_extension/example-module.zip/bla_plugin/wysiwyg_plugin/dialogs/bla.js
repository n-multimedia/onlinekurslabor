function bla_markup_callback(node_id, node_title)
{
    return "[task]" + node_id +":"+node_title+ "[/task]";
}
Drupal.behaviors.linkit_extension.createCKDialog({"dialog_id": "blaDialog", "title": "bla einfugen", "inputlabel": "Aufgaben-Namen eingeben:", "linkit_profile_id": "tasks", "markup_callback": bla_markup_callback});
 