
// Create the dialog namespace.
Drupal.bla_plugin = Drupal.custom_general || {};
Drupal.bla_plugin.blaDialogButtons = Drupal.bla_plugin.blaDialogButtons || {};

(function($) {
  

  CKEDITOR.plugins.add( 'bla_plugin', {
      icons:'bla',
    init: function( editor ){
         editor.addCommand( 'bla_command', new CKEDITOR.dialogCommand( 'blaDialog' ) );
      editor.ui.addButton( 'bla_button', {
        label: 'Bla', //this is the tooltip text for the button
        command: 'bla_command',
       icon: this.path + 'images/tasks.gif',
      toolbar: 'insert'
      });
   
// Register our dialog file -- this.path is the plugin folder path.
CKEDITOR.dialog.add( 'blaDialog', this.path + 'dialogs/bla.js' );
    }
  });


})(jQuery);

 
 